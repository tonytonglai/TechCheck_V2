//
//  ProblemEntityList+CoreDataClass.swift
//  CSC216-TechCheck-App
//
//  Created by Tony Lai on 2/12/2022.
//
//

import Foundation
import CoreData

@objc(ProblemEntityList)
public class ProblemEntityList: NSManagedObject {

}
