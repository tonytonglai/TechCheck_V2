//
//  CardView.swift
//  CSC216-TechCheck-App
//
//  Created by Tony Lai on 3/12/2022.
//

import UIKit

class CardView: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    
//    override func draw(_ layer: CALayer, in ctx: CGContext) {
//        <#code#>
//    }
//    self.layer.cornerRadius = 10
    
}
